#!/bin/bash
sudo yum install -y nodejs
