#!/bin/bash
#sudo yum install -y curl 
#curl -sL https://rpm.nodesource.com/setup_12.x | bash -
#sudo yum install -y nodejs
sudo yum install -y nginx 
