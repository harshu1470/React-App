#!/bin/bash

sudo systemctl stop nginx
