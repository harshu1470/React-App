#!/bin/bash

sudo systemctl restart nginx

