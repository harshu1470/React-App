#A!/bin/bash

sudo systemctl start nginx
